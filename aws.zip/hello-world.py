print ('Hello , World')
